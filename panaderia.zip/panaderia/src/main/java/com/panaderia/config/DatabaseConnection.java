package com.panaderia.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

    private static final String URL = "jdbc:postgresql://localhost:5432/panaderia_db";
    private static final String USER = "postgres";
    private static final String PASSWORD = "admin123"; // tu contraseña

    public static Connection getConnection() throws Exception {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}