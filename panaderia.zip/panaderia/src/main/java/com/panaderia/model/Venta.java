package com.panaderia.model;

import java.util.List;

public class Venta {
    private int id;
    private List<DetallePedido> detalles;
    private double total;
    private String metodoPago;

    public Venta(int id, List<DetallePedido> detalles, String metodoPago) {
        this.id = id;
        this.detalles = detalles;
        this.metodoPago = metodoPago;
        calcularTotal();
    }

    private void calcularTotal() {
        total = detalles.stream()
                .mapToDouble(d -> d.getSubtotal())
                .sum();
    }

    public double getTotal() {
        return total;
    }
}