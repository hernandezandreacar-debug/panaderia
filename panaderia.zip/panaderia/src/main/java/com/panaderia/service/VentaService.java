package com.panaderia.service;

import com.panaderia.config.DatabaseConnection;
import com.panaderia.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class VentaService {

    public void procesarVenta(List<DetallePedido> detalles, String metodoPago) {

        try (Connection conn = DatabaseConnection.getConnection()) {

            conn.setAutoCommit(false); // 🔥 transacción

            double total = detalles.stream()
                    .mapToDouble(DetallePedido::getSubtotal)
                    .sum();

            // 1. Insertar venta
            String sqlVenta = "INSERT INTO venta (total, metodo_pago) VALUES (?, ?) RETURNING id";
            PreparedStatement psVenta = conn.prepareStatement(sqlVenta);
            psVenta.setDouble(1, total);
            psVenta.setString(2, metodoPago);

            ResultSet rs = psVenta.executeQuery();
            rs.next();
            int ventaId = rs.getInt("id");

            // 2. Insertar detalles + actualizar stock
            for (DetallePedido d : detalles) {

                Producto p = d.getProducto();

                // VALIDAR STOCK REAL
                if (p.getStock() < d.getCantidad()) {
                    throw new RuntimeException("Stock insuficiente para: " + p.getNombre());
                }

                // Insertar detalle
                String sqlDetalle = """
                    INSERT INTO detalle_venta (venta_id, producto_id, cantidad, subtotal)
                    VALUES (?, ?, ?, ?)
                """;

                PreparedStatement psDetalle = conn.prepareStatement(sqlDetalle);
                psDetalle.setInt(1, ventaId);
                psDetalle.setInt(2, p.getId());
                psDetalle.setInt(3, d.getCantidad());
                psDetalle.setDouble(4, d.getSubtotal());
                psDetalle.executeUpdate();

                // 🔥 ACTUALIZAR STOCK EN BD
                String sqlStock = "UPDATE producto SET stock = stock - ? WHERE id = ?";
                PreparedStatement psStock = conn.prepareStatement(sqlStock);
                psStock.setInt(1, d.getCantidad());
                psStock.setInt(2, p.getId());
                psStock.executeUpdate();
            }

            conn.commit(); // ✅ todo correcto

            System.out.println("✅ Venta guardada correctamente");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Error en la venta");
        }
    }
}