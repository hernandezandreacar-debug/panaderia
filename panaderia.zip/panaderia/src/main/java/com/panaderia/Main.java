package com.panaderia;

import com.panaderia.model.*;
import com.panaderia.service.*;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        InventarioService inventario = new InventarioService();
        VentaService ventaService = new VentaService();

        Scanner sc = new Scanner(System.in);

        System.out.println("📦 PRODUCTOS DISPONIBLES:");

        for (Producto p : inventario.listarProductos()) {
            System.out.println(p.getId() + " - " + p.getNombre() +
                    " $" + p.getPrecio() +
                    " Stock: " + p.getStock());
        }

        List<DetallePedido> carrito = new ArrayList<>();

        System.out.print("ID producto: ");
        int id = sc.nextInt();

        System.out.print("Cantidad: ");
        int cant = sc.nextInt();

        Producto p = inventario.buscarPorId(id);

        if (p == null) {
            System.out.println("❌ Producto no existe");
            return;
        }

        if (p.getStock() < cant) {
            System.out.println("❌ Stock insuficiente");
            return;
        }

        carrito.add(new DetallePedido(p, cant));

        String metodo = "Efectivo";

        ventaService.procesarVenta(carrito, metodo);

        System.out.println("✅ Venta realizada correctamente");
    }
}